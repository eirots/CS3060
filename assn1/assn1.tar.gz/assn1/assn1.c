/*
Andrew Storie
CS 3060-X02 Spring 2025
Assignment 1
*/

/* Promise of Originality 
I promise that this source code file has, in its entirety, been written by myself and no other person or persons. 
If at any time an exact copy of this source code is found to be used by another person in this term, I understand that both 
myself and the student that submitted the copy will receive a zero on this assignment.

*/

#include <stdio.h>

int main(int argc, char *arv[]){
	printf("Assignment 1 by Andrew Storie\n");
	printf("This program will take inputs, and print them out one at a time\n");
	
	for(int i = 0; i<argc; i++){
		printf("%s\n", arv[i]);
	}

	printf( "\nnumber of arguments printed: %d\n\n", argc);

	return 0;
}
